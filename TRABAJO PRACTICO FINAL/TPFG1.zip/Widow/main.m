clc; clear all;close all
Automacion_GUI
clc
disp('Welcome to Group 1 Final Assignment')
